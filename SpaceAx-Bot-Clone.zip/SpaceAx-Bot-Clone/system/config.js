const { Function, Scraper } = new (require('@neoxr/neoxr-js'))
// Owner number
global.owner = '6288989048234', '6289668196304'
// Owner name
global.owner_name = 'X Star Zeus Programmer'
// Database name (Default: database)
global.database = 'SpaceAxDb'
// Maximum upload file size limit (Default : 100 MB)
global.max_upload = 100
// Delay for spamming protection (Default : 3 seconds)
global.cooldown = 3
// User Limitation (Default : 25)
global.limit = 15
// Time to be temporarily banned and others (Default : 30 minutes)
global.timer = 1800000
// Symbols that are excluded when adding a prefix (Don't change it)
global.evaluate_chars = ['=>', '~>', '<', '>', '$']
// Country code that will be automatically blocked by the system, when sending messages in private chat
global.blocks = ['91', '92', '212']
// Put target jid to forward friends story
global.forwards = global.owner + '@c.us'
//Random Data Apikey at https://api.neoxr.my.id
//const apikeydata = ['iAOmS0', 'X4jmPu', 'sydKtE', 'L8hYCP'];

//function getRandomData() {
  //const randomIndex = Math.floor(Math.random() * apikeydata.length);
  //return data[randomIndex];
//const ApiKey = ['iAOmS0', 'X4jmPu', 'sydKtE', 'L8hYCP'];
//const randomApiKey = ApiKey[Math.floor(Math.random() * ApiKey.length)];
//global.Api = new (require('./neoxrApi'))(randomApiKey)
// Get neoxr apikey by registering at https://api.neoxr.my.id
global.Api = new (require('./SpaceAx'))(process.env.X4jmPu)
// Timezone (Default : Asia/Jakarta)
global.timezone = 'Asia/Jakarta'
// Bot version
global.version = '1.5',
// Bot name
global.botname = `© SpaceAx-Bot v${global.version} (X Star Zeus Programmer)`
// Footer text
global.footer = 'SpaceAx-Bot By X Star Zeus Programmer'
// Scraper
global.scrap = Scraper
// Function
global.Func = Function
// Global status
global.status = Object.freeze({
   wait: Func.texted('bold', 'Processed . . .'),
   invalid: Func.texted('bold', 'URL is Invalid!'),
   wrong: Func.texted('bold', 'Format Salah!'),
   getdata: Func.texted('bold', 'Mengambil Data . . .'),
   fail: Func.texted('bold', 'Tidak Dapat Mengambil Data!'),
   //limitapikey: Func.texted('bold', 'Maaf Request Anda Telah Melenihi Batas!'),
   error: Func.texted('bold', 'Error occurred!'),
   errorF: Func.texted('bold', 'Maaf fitur ini error/Request Anda Telah Melenihi Batas!.'),
   premium: Func.texted('bold', 'Fitur Ini Hanya Untuk User Premium.'),
   owner: Func.texted('bold', 'Fitur Ini Hanya Untuk Owner.'),
   god: Func.texted('bold', 'Perintah Ini Hanya Untuk Master'),
   group: Func.texted('bold', 'Perintah Ini Akan Bekerja Jika Di Grup.'),
   botAdmin: Func.texted('bold', 'Perintah Ini Akan Bekerja Jika Saya Adalah Admin.'),
   admin: Func.texted('bold', 'Perintah Ini hanya Untuk Admin.'),
   private: Func.texted('bold', 'Gunakan Perintah Ini Di Private Chat.')
})